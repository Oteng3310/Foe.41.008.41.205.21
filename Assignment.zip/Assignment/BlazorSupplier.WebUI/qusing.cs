﻿internal class qusing
{
}